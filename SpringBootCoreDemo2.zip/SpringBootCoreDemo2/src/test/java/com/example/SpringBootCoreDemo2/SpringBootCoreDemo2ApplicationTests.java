package com.example.SpringBootCoreDemo2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCoreDemo2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
